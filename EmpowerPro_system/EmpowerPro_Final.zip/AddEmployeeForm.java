// AddEmployeeForm.java — Polished ✨ With Validation, Animation, Live Input Feedback, Dropdowns, Smart Defaults, and Focus Fix
import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Duration;

public class AddEmployeeForm {
    public static void display(EmployeeManager manager, Runnable onDataChanged) {
        Stage window = new Stage();
        window.setTitle("Add Employee");

        TextField name = new TextField("John Doe");
        name.setPromptText("Name");

        TextField ssn = new TextField("123456789");
        ssn.setPromptText("SSN");

        ComboBox<String> title = new ComboBox<>(FXCollections.observableArrayList(
                "Engineer", "Analyst", "Manager", "Designer", "Technician"
        ));
        title.setPromptText("Job Title");
        title.setEditable(true);
        title.getEditor().textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.trim().isEmpty()) {
                title.setStyle("-fx-border-color: green;");
            } else {
                title.setStyle("-fx-border-color: red;");
            }
        });

        ComboBox<String> division = new ComboBox<>(FXCollections.observableArrayList(
                "IT", "HR", "Finance", "Operations", "Marketing"
        ));
        division.setPromptText("Division");
        division.setEditable(true);
        division.getEditor().textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.trim().isEmpty()) {
                division.setStyle("-fx-border-color: green;");
            } else {
                division.setStyle("-fx-border-color: red;");
            }
        });

        TextField salary = new TextField();
        salary.setPromptText("Salary");
        salary.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal.matches("\\d+(\\.\\d+)?")) {
                salary.setStyle("-fx-border-color: green;");
            } else {
                salary.setStyle("-fx-border-color: red;");
            }
        });

        Button submit = new Button("Submit");
        submit.setOnAction(e -> {
            try {
                double sal = Double.parseDouble(salary.getText());
                manager.addEmployee(name.getText(), ssn.getText(), title.getEditor().getText(), division.getEditor().getText(), sal);
                if (onDataChanged != null) onDataChanged.run();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
alert.setTitle("Success");
alert.setHeaderText(null);
alert.setContentText("Employee added successfully!");

alert.setOnHidden(ev -> {
    if (onDataChanged != null) onDataChanged.run();
    window.close();
    Platform.runLater(() -> {
        for (Window w : Stage.getWindows()) {
            if (w.isShowing()) {
                w.requestFocus();
                break;
            }
        }
    });
});
alert.show();

                Platform.runLater(() -> {
                    Stage primaryStage = (Stage) Stage.getWindows().filtered(Window::isShowing).get(0);
                    primaryStage.requestFocus();
                });
            } catch (NumberFormatException ex) {
                showAnimatedAlert("Error", "Please enter a valid number for salary.");
            } catch (Exception ex) {
                showAnimatedAlert("Error", "Something went wrong while adding employee.");
                ex.printStackTrace();
            }
        });

        VBox layout = new VBox(10, name, ssn, title, division, salary, submit);
        layout.setStyle("-fx-padding: 20;");
        window.setScene(new Scene(layout, 300, 350));
        window.show();
    }

    private static void showAnimatedAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        Stage alertStage = (Stage) alert.getDialogPane().getScene().getWindow();
        FadeTransition fadeIn = new FadeTransition(Duration.millis(400), alert.getDialogPane());
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.play();
        alertStage.setOpacity(0);
        alertStage.show();
        FadeTransition fadeStage = new FadeTransition(Duration.millis(400), alertStage.getScene().getRoot());
        fadeStage.setFromValue(0);
        fadeStage.setToValue(1);
        fadeStage.play();
    }
}
